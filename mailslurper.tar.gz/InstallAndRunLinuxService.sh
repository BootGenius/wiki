#!/bin/bash

cat > /etc/systemd/system/mailslurper.service << EOL
[Unit]
Description=Test Mail Service

[Service]

#change this to your workspace
WorkingDirectory=$PWD

#path to executable. 
#executable is a bash script which calls jar file
ExecStart=$PWD/mailslurper

SuccessExitStatus=143
TimeoutStopSec=10
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOL

systemctl daemon-reload
systemctl enable mailslurper.service
systemctl start mailslurper
